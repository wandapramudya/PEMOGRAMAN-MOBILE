# E-Learning Mobile Application (Android Studio)

Aplikasi pembelajaran jarak jauh berbasis Android yang interaktif, mendukung lokalisasi multi-bahasa, kuis materi, dan pemantauan progres belajar melalui statistik grafik.

## 👨‍🏫 Dosen Pengampu
**Donny Maulana, S.Kom., M.M.S.I.**

---

## 🌟 Fitur Utama
* **Multi-Language Support**: Mendukung 5 bahasa internasional (English, Indonesia, Arabic, Japanese, dan Mandarin).
* **Interactive Dashboard**: Tampilan modern untuk memilih berbagai kategori materi (Web Design, IT, Photography, Business).
* **Quiz System**: Evaluasi pemahaman pengguna dengan skor dinamis dan feedback instan.
* **Study Progress Tracker**: Grafik batang yang memvisualisasikan skor atau jam belajar harian pengguna secara real-time.
* **Persistent Storage**: Menyimpan skor kuis menggunakan `SharedPreferences`.

## 🛠️ Teknologi yang Digunakan
* **Bahasa Pemrograman**: Java
* **IDE**: Android Studio
* **UI Components**: Material Design, CardView, BottomNavigationView, Custom Bar Chart (using Views).
* **Localization**: XML String Resources (`res/values`).

## 📁 Struktur Proyek (Penting)
Untuk mendukung fitur multi-bahasa, pastikan folder `res` kamu terstruktur sebagai berikut:
- `values/` (Default - English)
- `values-in/` (Bahasa Indonesia)
- `values-ar/` (Arabic)
- `values-ja/` (Japanese)
- `values-zh/` (Chinese Simplified)

## 🚀 Cara Menjalankan
1.  Clone repository ini.
2.  Buka project di **Android Studio**.
3.  Tunggu proses **Gradle Sync** selesai.
4.  Run aplikasi di Emulator atau Device fisik.
5.  Ubah bahasa pada *Splash Screen* atau *Settings* HP untuk melihat perubahan lokalisasi.

---
© 2024 E-Learning App Project. All Rights Reserved.