package com.example.e_learning;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MateriActivity extends AppCompatActivity {

    private String materialType; // Pindahkan ke variable global agar bisa diakses BottomNav

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materi);

        // Inisialisasi View
        TextView tvTitle = findViewById(R.id.tv_title_materi);
        TextView tvShortDesc = findViewById(R.id.tv_short_desc);
        TextView tvSubtitle = findViewById(R.id.tv_subtitle);
        TextView tvFullDesc = findViewById(R.id.tv_full_desc);
        ImageView imgMateri = findViewById(R.id.img_materi);
        ImageView btnBack = findViewById(R.id.btn_back);
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // Tombol Back
        btnBack.setOnClickListener(v -> finish());

        // Ambil data dari Dashboard
        materialType = getIntent().getStringExtra("TIPE_MATERI");

        if (materialType != null) {
            setupContent(tvTitle, tvShortDesc, tvSubtitle, tvFullDesc, imgMateri);
        }

        // --- LOGIKA NAVBAR TERPADU ---
        bottomNav.setSelectedItemId(R.id.nav_materi);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                // Balik ke Dashboard dan bersihkan tumpukan halaman
                Intent intent = new Intent(this, DashboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_materi) {
                return true; // Tetap di sini karena sedang baca materi
            } else if (id == R.id.nav_quiz) {
                // Buka Quiz sesuai dengan tipe materi yang sedang dibaca!
                Intent intent = new Intent(this, QuizActivity.class);
                intent.putExtra("TIPE_MATERI", materialType);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_stats) {
                Intent intent = new Intent(this, GrafikActivity.class);
                startActivity(intent);
                return true;
            }
            return false;
        });
    }

    // Memindahkan switch case ke fungsi terpisah agar onCreate lebih bersih
    private void setupContent(TextView title, TextView sDesc, TextView sub, TextView fDesc, ImageView img) {
        switch (materialType) {
            case "WEB":
                title.setText(getString(R.string.title_web_detail));
                sDesc.setText(getString(R.string.short_web));
                sub.setText(getString(R.string.sub_web));
                fDesc.setText(getString(R.string.desc_web_full));
                img.setImageResource(R.drawable.student);
                break;
            case "IT":
                title.setText(getString(R.string.title_it_detail));
                sDesc.setText(getString(R.string.short_it));
                sub.setText(getString(R.string.sub_it));
                fDesc.setText(getString(R.string.desc_it_full));
                img.setImageResource(R.drawable.student);
                break;
            case "PHOTO":
                title.setText(getString(R.string.title_photo_detail));
                sDesc.setText(getString(R.string.short_photo));
                sub.setText(getString(R.string.sub_photo));
                fDesc.setText(getString(R.string.desc_photo_full));
                img.setImageResource(R.drawable.student);
                break;
            case "BIZ":
                title.setText(getString(R.string.title_biz_detail));
                sDesc.setText(getString(R.string.short_biz));
                sub.setText(getString(R.string.sub_biz));
                fDesc.setText(getString(R.string.desc_biz_full));
                img.setImageResource(R.drawable.student);
                break;
        }
    }
}