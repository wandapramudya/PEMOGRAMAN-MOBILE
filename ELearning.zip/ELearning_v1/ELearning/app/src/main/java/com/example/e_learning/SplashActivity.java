package com.example.e_learning;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.FrameLayout;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. SET DEFAULT KE ENGLISH sebelum layout muncul
        setDefaultLanguage("en");

        setContentView(R.layout.activity_splash);

        // Inisialisasi Tombol (Sesuai dengan XML yang kita bahas sebelumnya)
        setupLanguageButton(R.id.btn_english, "en");
        setupLanguageButton(R.id.btn_china, "zh");
        setupLanguageButton(R.id.btn_japan, "ja");
        setupLanguageButton(R.id.btn_arab, "ar");
        setupLanguageButton(R.id.btn_indonesia, "in");
    }

    private void setupLanguageButton(int id, final String langCode) {
        FrameLayout btn = findViewById(id);
        if (btn != null) {
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    setLocale(langCode);
                }
            });
        }
    }

    // Fungsi untuk memaksa aplikasi menggunakan bahasa tertentu
    private void setLocale(String langCode) {
        Locale myLocale = new Locale(langCode);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.setLocale(myLocale);
        res.updateConfiguration(conf, dm);

        // Pindah ke LoginActivity setelah bahasa dipilih
        Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    // Fungsi pembantu agar saat pertama buka aplikasi, English jadi default
    private void setDefaultLanguage(String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
    }
}