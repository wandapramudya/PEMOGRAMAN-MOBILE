package com.example.e_learning;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class GrafikActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafik);


        // 2. Setup Bottom Navigation (Pastikan ID nav_stats/nav_grafik sinkron)
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_stats); // Gunakan ID yang ada di menu XML kamu

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                Intent intent = new Intent(this, DashboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_materi) {
                // Berasumsi kembali ke menu materi default
                Intent intent = new Intent(this, DashboardActivity.class);
                intent.putExtra("TARGET_MENU", "MATERI");
                startActivity(intent);
                return true;
            }
            return id == R.id.nav_stats;
        });

        // 3. Ambil Data Skor dari SharedPreferences
        SharedPreferences prefs = getSharedPreferences("USER_SCORES", MODE_PRIVATE);
        int scoreWeb = prefs.getInt("SCORE_WEB", 0);
        int scoreIT = prefs.getInt("SCORE_IT", 0);
        int scorePhoto = prefs.getInt("SCORE_PHOTO", 0);
        int scoreBiz = prefs.getInt("SCORE_BIZ", 0);

        // 4. Update Tampilan Grafik Batang secara Dinamis
        // Kita mengubah tinggi (height) View berdasarkan skor
        updateBarHeight(findViewById(R.id.bar_mon), scoreWeb);  // Contoh: Web dipasang di hari Senin
        updateBarHeight(findViewById(R.id.bar_tue), scoreIT);   // Contoh: IT dipasang di hari Selasa
        updateBarHeight(findViewById(R.id.bar_wed), scorePhoto);
        updateBarHeight(findViewById(R.id.bar_thu), scoreBiz);

        // 5. Update teks skor di Card Kursus (Jika ada ID-nya di XML)
        // tvScoreWeb.setText(scoreWeb + "/100");
    }

    /**
     * Fungsi untuk mengubah tinggi batang grafik secara dinamis
     * @param barView View yang akan diubah tingginya
     * @param score Nilai skor (0-100)
     */
    private void updateBarHeight(View barView, int score) {
        if (barView != null) {
            // Kita konversi skor menjadi tinggi dalam pixel
            // Misal: Skor 100 = tinggi 200dp
            float scale = getResources().getDisplayMetrics().density;
            int heightInDp = score * 2; // Skala 1:2
            int heightInPx = (int) (heightInDp * scale);

            ViewGroup.LayoutParams params = barView.getLayoutParams();
            params.height = heightInPx;
            barView.setLayoutParams(params);
        }
    }
}