package com.example.e_learning;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class QuizActivity extends AppCompatActivity {

    private TextView tvQuestion, tvNumber, tvTitle;
    private Button btnOpt1, btnOpt2, btnOpt3, btnOpt4;
    private String materialType;
    private int currentQuestion = 1;
    private int score = 0; // Tambahan variabel skor

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // 1. Inisialisasi View
        tvTitle = findViewById(R.id.tv_quiz_title);
        tvQuestion = findViewById(R.id.tv_question_text);
        tvNumber = findViewById(R.id.tv_question_number);
        btnOpt1 = findViewById(R.id.btn_option1);
        btnOpt2 = findViewById(R.id.btn_option2);
        btnOpt3 = findViewById(R.id.btn_option3);
        btnOpt4 = findViewById(R.id.btn_option4);
        ImageView btnBack = findViewById(R.id.btn_back_quiz);
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // 2. Tombol Back
        btnBack.setOnClickListener(v -> finish());

        // 3. Setup Bottom Navigation Lengkap
        bottomNav.setSelectedItemId(R.id.nav_quiz);
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                Intent intent = new Intent(this, DashboardActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                return true;
            } else if (id == R.id.nav_materi) {
                finish();
                return true;
            } else if (id == R.id.nav_stats) {
                startActivity(new Intent(this, GrafikActivity.class));
                return true;
            }
            return id == R.id.nav_quiz;
        });

        // 4. Ambil data tipe materi & muat soal
        materialType = getIntent().getStringExtra("TIPE_MATERI");
        loadQuestion();
    }

    private void loadQuestion() {
        if (materialType == null) return;

        String stepText = getString(R.string.question_step) + " " + currentQuestion + "/2";
        tvNumber.setText(stepText);

        if (currentQuestion == 1) {
            switch (materialType) {
                case "WEB":
                    tvTitle.setText(getString(R.string.title_web_detail));
                    tvQuestion.setText(getString(R.string.q_web_1));
                    setOptions("Hyper Text Markup Language", "High Tech Modern Language", "Hyper Tool Multi Language", "Home Tool Markup Language", 1);
                    break;
                case "IT":
                    tvTitle.setText(getString(R.string.title_it_detail));
                    tvQuestion.setText(getString(R.string.q_it_1));
                    setOptions("Windows", "Google Chrome", "Microsoft Word", "Photoshop", 1);
                    break;
                case "PHOTO":
                    tvTitle.setText(getString(R.string.title_photo_detail));
                    tvQuestion.setText(getString(R.string.q_photo_1));
                    setOptions("Camera Sensitivity", "Lens Width", "Shutter Speed", "Resolution", 1);
                    break;
                case "BIZ":
                    tvTitle.setText(getString(R.string.title_biz_detail));
                    tvQuestion.setText(getString(R.string.q_biz_1));
                    setOptions("Return on Investment", "Risk of Interest", "Rate of Income", "Inventory", 1);
                    break;
            }
        } else {
            switch (materialType) {
                case "WEB":
                    tvQuestion.setText(getString(R.string.q_web_2));
                    setOptions("<img>", "<link>", "<src>", "<a>", 1);
                    break;
                case "IT":
                    tvQuestion.setText(getString(R.string.q_it_2));
                    setOptions("CPU", "RAM", "HDD", "GPU", 1);
                    break;
                case "PHOTO":
                    tvQuestion.setText(getString(R.string.q_photo_2));
                    setOptions("Composition", "Lighting", "Focus", "Zooming", 1);
                    break;
                case "BIZ":
                    tvQuestion.setText(getString(R.string.q_biz_2));
                    setOptions("Business to Business", "Back to Business", "Brand to Buyer", "Buyer", 1);
                    break;
            }
        }
    }

    private void setOptions(String o1, String o2, String o3, String o4, int correct) {
        btnOpt1.setText(o1); btnOpt2.setText(o2); btnOpt3.setText(o3); btnOpt4.setText(o4);
        btnOpt1.setOnClickListener(v -> checkAnswer(1, correct));
        btnOpt2.setOnClickListener(v -> checkAnswer(2, correct));
        btnOpt3.setOnClickListener(v -> checkAnswer(3, correct));
        btnOpt4.setOnClickListener(v -> checkAnswer(4, correct));
    }

    private void checkAnswer(int selected, int correct) {
        if (selected == correct) {
            score += 50; // Skor bertambah
            Toast.makeText(this, getString(R.string.correct), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, getString(R.string.wrong), Toast.LENGTH_SHORT).show();
        }

        // Delay 600ms agar user bisa lihat toast sebelum lanjut/popup muncul
        new Handler().postDelayed(() -> {
            if (currentQuestion < 2) {
                currentQuestion++;
                loadQuestion();
            } else {
                showScorePopup();
            }
        }, 600);
    }

    private void showScorePopup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.quiz_results));
        builder.setMessage(getString(R.string.your_score) + score + "\n" + getString(R.string.quiz_dialog_msg));
        builder.setCancelable(false);

        // Tombol Ulangi
        builder.setPositiveButton(getString(R.string.btn_retry), (dialog, which) -> {
            score = 0;
            currentQuestion = 1;
            loadQuestion();
        });

        // Tombol Selesai
        builder.setNegativeButton(getString(R.string.btn_finish), (dialog, which) -> finish());

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}