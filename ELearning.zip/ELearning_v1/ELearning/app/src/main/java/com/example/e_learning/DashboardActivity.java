package com.example.e_learning;

import android.content.Intent;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        // Pengaturan padding sistem (Edge-to-Edge)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        // 1. Logika Klik CardView di Dashboard (Membuka Materi Spesifik)
        setupCardClicks();

        // 2. Logika Bottom Navigation
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setSelectedItemId(R.id.nav_home); // Dashboard adalah Home

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_home) {
                // Sudah di Dashboard, tidak perlu pindah
                return true;
            } else if (id == R.id.nav_materi) {
                // Ke halaman Materi (Default: WEB)
                bukaHalaman("MATERI", "WEB");
                return true;
            } else if (id == R.id.nav_quiz) {
                // Ke halaman Quiz (Default: WEB)
                bukaHalaman("QUIZ", "WEB");
                return true;
            } else if (id == R.id.nav_stats) { // Pastikan ID ini ada di menu/bottom_nav_menu.xml
                // Ke halaman Grafik/Statistik
                bukaHalaman("GRAFIK", null);
                return true;
            }
            return false;
        });
    }

    private void setupCardClicks() {
        findViewById(R.id.card_web_design).setOnClickListener(v -> bukaHalaman("MATERI", "WEB"));
        findViewById(R.id.card_it).setOnClickListener(v -> bukaHalaman("MATERI", "IT"));
        findViewById(R.id.card_photography).setOnClickListener(v -> bukaHalaman("MATERI", "PHOTO"));
        findViewById(R.id.card_business).setOnClickListener(v -> bukaHalaman("MATERI", "BIZ"));
    }

    // Fungsi universal untuk pindah halaman agar kode tidak berantakan
    private void bukaHalaman(String menu, String tipe) {
        Intent intent;
        switch (menu) {
            case "MATERI":
                intent = new Intent(this, MateriActivity.class);
                intent.putExtra("TIPE_MATERI", tipe);
                break;
            case "QUIZ":
                intent = new Intent(this, QuizActivity.class);
                intent.putExtra("TIPE_MATERI", tipe);
                break;
            case "GRAFIK":
                // Jika kamu belum buat GrafikActivity, buat dulu filenya
                intent = new Intent(this, GrafikActivity.class);
                break;
            default:
                return;
        }

        // Mencegah penumpukan activity yang sama
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}