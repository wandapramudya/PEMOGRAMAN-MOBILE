package com.example.e_learning;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword;
    private TextView btnGoogle;
    private Button btnLoginMain; // Tambahkan variabel untuk tombol login baru

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inisialisasi komponen UI
        initViews();

        // Logika klik untuk Tombol Login Utama
        if (btnLoginMain != null) {
            btnLoginMain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    performLogin();
                }
            });
        }

        // Logika klik untuk teks "Sign in with Google"
        if (btnGoogle != null) {
            btnGoogle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Sementara kita arahkan ke login yang sama
                    performLogin();
                }
            });
        }
    }

    private void initViews() {
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnGoogle = findViewById(R.id.btn_google);
        btnLoginMain = findViewById(R.id.btn_login_main); // Pastikan ID ini sama dengan di XML
    }

    private void performLogin() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Validasi input
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Harap lengkapi semua data", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Welcome " + name, Toast.LENGTH_SHORT).show();

            // Berpindah ke WelcomeActivity
            Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
            startActivity(intent);

            // Mengakhiri LoginActivity agar user tidak bisa kembali
            finish();
        }
    }
}